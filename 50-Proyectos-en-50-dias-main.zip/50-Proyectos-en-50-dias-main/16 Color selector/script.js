function CambiarRojo(){
    document.body.style.backgroundColor = '#f00';
}

function CambiarBlanco(){
    document.body.style.backgroundColor = '#0f0';
}

function CambiarNegro(){
    document.body.style.backgroundColor = '#000';
}