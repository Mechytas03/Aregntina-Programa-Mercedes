function muestra1(){
	document.getElementById("primero").style.display = "block";
    document.getElementById("segundo").style.display = "none";
    document.getElementById("tercero").style.display = "none";
}

function muestra2(){
    document.getElementById('primero').style.display = "none";
	document.getElementById('segundo').style.display = "block";
	document.getElementById('tercero').style.display = "none";
}

function muestra3(){
    document.getElementById("primero").style.display = "none";
    document.getElementById("segundo").style.display = "none";
    document.getElementById("tercero").style.display = "block";
}